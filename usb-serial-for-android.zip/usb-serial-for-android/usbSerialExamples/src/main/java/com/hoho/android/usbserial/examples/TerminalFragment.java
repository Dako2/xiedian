package com.hoho.android.usbserial.examples;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.nfc.Tag;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.hoho.android.usbserial.driver.UsbSerialDriver;
import com.hoho.android.usbserial.driver.UsbSerialPort;
import com.hoho.android.usbserial.driver.UsbSerialProber;
import com.hoho.android.usbserial.util.HexDump;
import com.hoho.android.usbserial.util.SerialInputOutputManager;

import java.io.IOException;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.LinkedList;
import android.widget.ImageView;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import java.io.File;
import android.os.Environment;
import java.io.FileWriter;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.content.pm.PackageManager;

import android.content.pm.PackageManager;
import androidx.core.content.ContextCompat;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import android.util.Log;

public class TerminalFragment extends Fragment implements SerialInputOutputManager.Listener {
    private File file;
    private static final String TAG = "Dako";

    private SensorManager sensorManager;

    private Sensor accelerometer;
    private Sensor gyroscope;
    private Sensor magnetometer;

    private ImageView feetImageView;
    private TextView textViewR18;
    private TextView textViewR01;
    private TextView textViewR02;
    private TextView textViewR03;
    private TextView textViewR04;
    private TextView textViewR05;
    private TextView textViewR06;
    private TextView textViewR07;
    private TextView textViewR08;
    private TextView textViewR09;
    private TextView textViewR10;
    private TextView textViewR11;
    private TextView textViewR12;
    private TextView textViewR13;
    private TextView textViewR14;
    private TextView textViewR15;

    private TextView textViewR16;
    private TextView textViewR17;

    private enum UsbPermission { Unknown, Requested, Granted, Denied }

    private static final String INTENT_ACTION_GRANT_USB = BuildConfig.APPLICATION_ID + ".GRANT_USB";
    private static final int WRITE_WAIT_MILLIS = 2000;
    private static final int READ_WAIT_MILLIS = 2000;

    private int deviceId, portNum, baudRate;
    private boolean withIoManager;

    private final BroadcastReceiver broadcastReceiver;
    private final Handler mainLooper;
    private TextView receiveText;
    private ControlLines controlLines;

    private SerialInputOutputManager usbIoManager;
    private UsbSerialPort usbSerialPort;
    private UsbPermission usbPermission = UsbPermission.Unknown;
    private boolean connected = false;

    public TerminalFragment() {
        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if(INTENT_ACTION_GRANT_USB.equals(intent.getAction())) {
                    usbPermission = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                            ? UsbPermission.Granted : UsbPermission.Denied;
                    connect();
                }
            }
        };
        mainLooper = new Handler(Looper.getMainLooper());
    }

    /*
     * Lifecycle
     */
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setHasOptionsMenu(true);
        setRetainInstance(true);
        deviceId = getArguments().getInt("device");
        portNum = getArguments().getInt("port");
        baudRate = getArguments().getInt("baud");
        withIoManager = getArguments().getBoolean("withIoManager");

        // Initialize Sensor Manager and Sensor
        sensorManager = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        magnetometer = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

        File downloadDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        file = new File(downloadDirectory, "sensor_log.txt");

        try {
            if (!file.exists()) {
                file.createNewFile(); // Create the file if it doesn't exist
            }
        } catch (IOException e) {
            e.printStackTrace();
            // Handle file creation errors here
        }

        Log.d(TAG, "File path: " + file.toString()); // or file.getAbsolutePath()
    }
    SensorEventListener sensorEventListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {
            StringBuilder data = new StringBuilder();
            data.append(System.currentTimeMillis()); // Timestamp
            data.append(",");
            switch (event.sensor.getType()) {
                case Sensor.TYPE_ACCELEROMETER:
                    data.append("ACC"); // Label for Accelerometer
                    break;
                case Sensor.TYPE_GYROSCOPE:
                    data.append("GYRO"); // Label for Gyroscope
                    break;
                case Sensor.TYPE_MAGNETIC_FIELD:
                    data.append("MAG"); // Label for Magnetometer
                    break;
            }
            for (float value : event.values) {
                data.append(",").append(value);
            }
            receiveText.setText(data.toString());
            logDataToFile(file, data.toString());
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
            // Handle accuracy changes if necessary
        }
    };

    private void logDataToFile(File file, String data) {

        // Add a log statement to indicate that the data was saved
        // long epochTime = System.currentTimeMillis();
        String logEntry = data;
        //Log.d(TAG, "Data logging to: " + logEntry);
        Log.d(TAG, "Data logging to: " + file.toString());

        try (FileWriter writer = new FileWriter(file, true)) {
            writer.append(logEntry).append("\n");
            Log.d(TAG, "Data saved to file: " + file.getAbsolutePath());
        } catch (IOException e) {
            Log.d(TAG, "error saving data");
            e.printStackTrace();
            // Handle any file writing errors here
        }
        // Add a log statement to indicate that the data was saved


    }

    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getActivity() != null) {
            getActivity().registerReceiver(broadcastReceiver, new IntentFilter(INTENT_ACTION_GRANT_USB));
        }
        if (sensorManager != null) {
            sensorManager.registerListener(sensorEventListener, accelerometer, SensorManager.SENSOR_DELAY_NORMAL);
            sensorManager.registerListener(sensorEventListener, gyroscope, SensorManager.SENSOR_DELAY_NORMAL);
            sensorManager.registerListener(sensorEventListener, magnetometer, SensorManager.SENSOR_DELAY_NORMAL);
        }

        if(usbPermission == UsbPermission.Unknown || usbPermission == UsbPermission.Granted)
            mainLooper.post(this::connect);
    }

    @Override
    public void onPause() {
        if(connected) {
            status("disconnected");
            disconnect();
        }
        if (sensorManager != null) {
            sensorManager.unregisterListener(sensorEventListener);
        }

        if (getActivity() != null) {
            getActivity().unregisterReceiver(broadcastReceiver);
        }
        super.onPause();
    }

    /*
     * UI
     */
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_terminal, container, false);

        // Initialize the custom view Dako
        feetImageView = view.findViewById(R.id.feetImageView); // Make sure you have a View with this ID in your layout
        textViewR18 = view.findViewById(R.id.textViewR18);
        textViewR01 = view.findViewById(R.id.textViewR01);
        textViewR02 = view.findViewById(R.id.textViewR02);
        textViewR03 = view.findViewById(R.id.textViewR03);
        textViewR04 = view.findViewById(R.id.textViewR04);
        textViewR05 = view.findViewById(R.id.textViewR05);
        textViewR06 = view.findViewById(R.id.textViewR06);
        textViewR07 = view.findViewById(R.id.textViewR07);
        textViewR08 = view.findViewById(R.id.textViewR08);
        textViewR09 = view.findViewById(R.id.textViewR09);
        textViewR10 = view.findViewById(R.id.textViewR10);
        textViewR11 = view.findViewById(R.id.textViewR11);
        textViewR12 = view.findViewById(R.id.textViewR12);
        textViewR13 = view.findViewById(R.id.textViewR13);
        textViewR14 = view.findViewById(R.id.textViewR14);
        textViewR15 = view.findViewById(R.id.textViewR15);
        textViewR16 = view.findViewById(R.id.textViewR16);
        textViewR17 = view.findViewById(R.id.textViewR17);


        receiveText = view.findViewById(R.id.receive_text);      // TextView performance decreases with number of spans
        receiveText.setTextColor(getResources().getColor(R.color.colorRecieveText)); // set as default color to reduce number of spans
        receiveText.setMovementMethod(ScrollingMovementMethod.getInstance());
        TextView sendText = view.findViewById(R.id.send_text);
        View sendBtn = view.findViewById(R.id.send_btn);
        sendBtn.setOnClickListener(v -> send(sendText.getText().toString()));
        View receiveBtn = view.findViewById(R.id.receive_btn);
        controlLines = new ControlLines(view);
        if(withIoManager) {
            receiveBtn.setVisibility(View.GONE);
        } else {
            receiveBtn.setOnClickListener(v -> read());
        }
        return view;
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_terminal, menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.clear) {
            receiveText.setText("");
            return true;
        } else if( id == R.id.send_break) {
            if(!connected) {
                Toast.makeText(getActivity(), "not connected", Toast.LENGTH_SHORT).show();
            } else {
                try {
                    usbSerialPort.setBreak(true);
                    Thread.sleep(100); // should show progress bar instead of blocking UI thread
                    usbSerialPort.setBreak(false);
                    SpannableStringBuilder spn = new SpannableStringBuilder();
                    spn.append("send <break>\n");
                    spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorSendText)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                    receiveText.append(spn);
                } catch(UnsupportedOperationException ignored) {
                    Toast.makeText(getActivity(), "BREAK not supported", Toast.LENGTH_SHORT).show();
                } catch(Exception e) {
                    Toast.makeText(getActivity(), "BREAK failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }
    }

    /*
     * Serial
     */
    @Override
    public void onNewData(byte[] data) {
        mainLooper.post(() -> {
            receive(data);
        });
    }

    @Override
    public void onRunError(Exception e) {
        mainLooper.post(() -> {
            status("connection lost: " + e.getMessage());
            disconnect();
        });
    }

    /*
     * Serial + UI
     */
    private void connect() {
        UsbDevice device = null;
        UsbManager usbManager = (UsbManager) getActivity().getSystemService(Context.USB_SERVICE);
        for(UsbDevice v : usbManager.getDeviceList().values())
            if(v.getDeviceId() == deviceId)
                device = v;
        if(device == null) {
            status("connection failed: device not found");
            return;
        }
        UsbSerialDriver driver = UsbSerialProber.getDefaultProber().probeDevice(device);
        if(driver == null) {
            driver = CustomProber.getCustomProber().probeDevice(device);
        }
        if(driver == null) {
            status("connection failed: no driver for device");
            return;
        }
        if(driver.getPorts().size() < portNum) {
            status("connection failed: not enough ports at device");
            return;
        }
        usbSerialPort = driver.getPorts().get(portNum);
        UsbDeviceConnection usbConnection = usbManager.openDevice(driver.getDevice());
        if(usbConnection == null && usbPermission == UsbPermission.Unknown && !usbManager.hasPermission(driver.getDevice())) {
            usbPermission = UsbPermission.Requested;
            int flags = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_MUTABLE : 0;
            PendingIntent usbPermissionIntent = PendingIntent.getBroadcast(getActivity(), 0, new Intent(INTENT_ACTION_GRANT_USB), flags);
            usbManager.requestPermission(driver.getDevice(), usbPermissionIntent);
            return;
        }
        if(usbConnection == null) {
            if (!usbManager.hasPermission(driver.getDevice()))
                status("connection failed: permission denied");
            else
                status("connection failed: open failed");
            return;
        }

        try {
            usbSerialPort.open(usbConnection);
            try{
                usbSerialPort.setParameters(baudRate, 8, 1, UsbSerialPort.PARITY_NONE);
            }catch (UnsupportedOperationException e){
                status("unsupport setparameters");
            }
            if(withIoManager) {
                usbIoManager = new SerialInputOutputManager(usbSerialPort, this);
                usbIoManager.start();
            }
            status("connected");
            connected = true;
            controlLines.start();
        } catch (Exception e) {
            status("connection failed: " + e.getMessage());
            disconnect();
        }
    }

    private void disconnect() {
        connected = false;
        controlLines.stop();
        if(usbIoManager != null) {
            usbIoManager.setListener(null);
            usbIoManager.stop();
        }
        usbIoManager = null;
        try {
            usbSerialPort.close();
        } catch (IOException ignored) {}
        usbSerialPort = null;
    }

    private void send(String str) {
        if(!connected) {
            Toast.makeText(getActivity(), "not connected", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
        byte[] data = (str + '\n').getBytes();
            SpannableStringBuilder spn = new SpannableStringBuilder();
            spn.append("send " + data.length + " bytes\n");
            spn.append(HexDump.dumpHexString(data)).append("\n");
            spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorSendText)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            receiveText.append(spn);
            usbSerialPort.write(data, WRITE_WAIT_MILLIS);
        } catch (Exception e) {
            onRunError(e);
        }
    }

    private void read() {
        if(!connected) {
            Toast.makeText(getActivity(), "not connected", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            byte[] buffer = new byte[8192];
            int len = usbSerialPort.read(buffer, READ_WAIT_MILLIS);
            receive(Arrays.copyOf(buffer, len));
        } catch (IOException e) {
            // when using read with timeout, USB bulkTransfer returns -1 on timeout _and_ errors
            // like connection loss, so there is typically no exception thrown here on error
            status("connection lost: " + e.getMessage());
            disconnect();
        }
    }

    // DAKO receive code
    private LinkedList<Byte> buffer = new LinkedList<>();
    private void receive(byte[] data) {
        // Add new data to the buffer
        for (byte b : data) {
            buffer.add(b);
        }

        // Process buffer while it has enough data for a packet
        while (buffer.size() >= 39) {
            // Check if the start of the buffer is frame header (AA)
            if (buffer.getFirst() == (byte) 0xAA) {
                // Extract a packet
                byte[] packet = new byte[39];
                for (int i = 0; i < 39; i++) {
                    packet[i] = buffer.removeFirst();
                }
                // Verify checksum before processing
                if (verifyChecksum(packet)) {
                    // Process the packet
                    processPacket(packet);
                } else {
                    // Handle checksum error
                    // You may want to log this error or take other actions
                }
            } else {
                // Not a packet start, remove the first byte and continue
                buffer.removeFirst();
            }
        }
    }

    private boolean verifyChecksum(byte[] packet) {
        int checksumCalculated = 0;
        for (int i = 0; i < packet.length - 1; i++) {
            checksumCalculated += (packet[i] & 0xFF);
        }
        checksumCalculated = checksumCalculated & 0xFF; // Take lower 8 bits

        int checksumReceived = packet[packet.length - 1] & 0xFF;
        return checksumCalculated == checksumReceived;
    }
    private void processPacket(byte[] packet) {
        byte[] data = packet;
        SpannableStringBuilder spn = new SpannableStringBuilder();
        spn.append("receive " + data.length + " bytes\n");
        spn.append(HexDump.dumpHexString(data)).append("\n");

        // Check for left or right foot
        String foot = (data[1] == (byte) 0x01) ? "LeftFoot" : (data[1] == (byte) 0x02) ? "RightFoot" : "UnknownFoot";
        spn.append(foot).append(" data\n");

        // Assuming sensorValues is an int array holding your sensor values
        int[] sensorValues = new int[18];

        for (int i = 2; i < packet.length - 2; i += 2) {
            sensorValues[(i / 2) - 1] = ((packet[i] & 0xFF) * 256) + (packet[i + 1] & 0xFF);
        }

        // Now update the custom view
        // sensorDataPoint1.setSensorValues(sensorValues);
        // Update TextViews with sensor values
        // Update TextViews with sensor values on the main thread
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                textViewR18.setText(String.valueOf(sensorValues[17]));
                textViewR01.setText(String.valueOf(sensorValues[0]));
                textViewR02.setText(String.valueOf(sensorValues[1]));
                textViewR03.setText(String.valueOf(sensorValues[2]));
                textViewR04.setText(String.valueOf(sensorValues[3]));
                textViewR05.setText(String.valueOf(sensorValues[4]));
                textViewR06.setText(String.valueOf(sensorValues[5]));
                textViewR07.setText(String.valueOf(sensorValues[6]));
                textViewR08.setText(String.valueOf(sensorValues[7]));
                textViewR09.setText(String.valueOf(sensorValues[8]));
                textViewR10.setText(String.valueOf(sensorValues[9]));
                textViewR11.setText(String.valueOf(sensorValues[10]));
                textViewR12.setText(String.valueOf(sensorValues[11]));
                textViewR13.setText(String.valueOf(sensorValues[12]));
                textViewR14.setText(String.valueOf(sensorValues[13]));
                textViewR15.setText(String.valueOf(sensorValues[14]));
                textViewR16.setText(String.valueOf(sensorValues[15]));
                textViewR17.setText(String.valueOf(sensorValues[16]));

            }
        });

        // Extracting sensor data
        for (int i = 2; i < data.length - 2; i += 2) {
            int sensorValue = ((data[i] & 0xFF) * 256) + (data[i + 1] & 0xFF);
            spn.append("Sensor point ").append(String.valueOf((i / 2) - 1)).append(": ").append(String.valueOf(sensorValue)).append("g\n");
        }
        receiveText.setText(spn);

        String sensorValuesString = Arrays.toString(sensorValues);
        sensorValuesString = sensorValuesString.substring(1, sensorValuesString.length() - 1);

        StringBuilder data_to_log = new StringBuilder();
        data_to_log.append(System.currentTimeMillis()); // Timestamp
        data_to_log.append(",");
        data_to_log.append(foot);
        data_to_log.append(",");
        data_to_log.append(sensorValuesString);
        logDataToFile(file, data_to_log.toString());
        Log.d(TAG, "save foot data" + foot + ","+ sensorValuesString);

    }

    void status(String str) {
        SpannableStringBuilder spn = new SpannableStringBuilder(str+'\n');
        spn.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.colorStatusText)), 0, spn.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        receiveText.append(spn);
    }

    class ControlLines {
        private static final int refreshInterval = 200; // msec

        private final Runnable runnable;
        private final ToggleButton rtsBtn, ctsBtn, dtrBtn, dsrBtn, cdBtn, riBtn;

        ControlLines(View view) {
            runnable = this::run; // w/o explicit Runnable, a new lambda would be created on each postDelayed, which would not be found again by removeCallbacks

            rtsBtn = view.findViewById(R.id.controlLineRts);
            ctsBtn = view.findViewById(R.id.controlLineCts);
            dtrBtn = view.findViewById(R.id.controlLineDtr);
            dsrBtn = view.findViewById(R.id.controlLineDsr);
            cdBtn = view.findViewById(R.id.controlLineCd);
            riBtn = view.findViewById(R.id.controlLineRi);
            rtsBtn.setOnClickListener(this::toggle);
            dtrBtn.setOnClickListener(this::toggle);
        }

        private void toggle(View v) {
            ToggleButton btn = (ToggleButton) v;
            if (!connected) {
                btn.setChecked(!btn.isChecked());
                Toast.makeText(getActivity(), "not connected", Toast.LENGTH_SHORT).show();
                return;
            }
            String ctrl = "";
            try {
                if (btn.equals(rtsBtn)) { ctrl = "RTS"; usbSerialPort.setRTS(btn.isChecked()); }
                if (btn.equals(dtrBtn)) { ctrl = "DTR"; usbSerialPort.setDTR(btn.isChecked()); }
            } catch (IOException e) {
                status("set" + ctrl + "() failed: " + e.getMessage());
            }
        }

        private void run() {
            if (!connected)
                return;
            try {
                EnumSet<UsbSerialPort.ControlLine> controlLines = usbSerialPort.getControlLines();
                rtsBtn.setChecked(controlLines.contains(UsbSerialPort.ControlLine.RTS));
                ctsBtn.setChecked(controlLines.contains(UsbSerialPort.ControlLine.CTS));
                dtrBtn.setChecked(controlLines.contains(UsbSerialPort.ControlLine.DTR));
                dsrBtn.setChecked(controlLines.contains(UsbSerialPort.ControlLine.DSR));
                cdBtn.setChecked(controlLines.contains(UsbSerialPort.ControlLine.CD));
                riBtn.setChecked(controlLines.contains(UsbSerialPort.ControlLine.RI));
                mainLooper.postDelayed(runnable, refreshInterval);
            } catch (Exception e) {
                status("getControlLines() failed: " + e.getMessage() + " -> stopped control line refresh");
            }
        }

        void start() {
            if (!connected)
                return;
            try {
                EnumSet<UsbSerialPort.ControlLine> controlLines = usbSerialPort.getSupportedControlLines();
                if (!controlLines.contains(UsbSerialPort.ControlLine.RTS)) rtsBtn.setVisibility(View.INVISIBLE);
                if (!controlLines.contains(UsbSerialPort.ControlLine.CTS)) ctsBtn.setVisibility(View.INVISIBLE);
                if (!controlLines.contains(UsbSerialPort.ControlLine.DTR)) dtrBtn.setVisibility(View.INVISIBLE);
                if (!controlLines.contains(UsbSerialPort.ControlLine.DSR)) dsrBtn.setVisibility(View.INVISIBLE);
                if (!controlLines.contains(UsbSerialPort.ControlLine.CD))   cdBtn.setVisibility(View.INVISIBLE);
                if (!controlLines.contains(UsbSerialPort.ControlLine.RI))   riBtn.setVisibility(View.INVISIBLE);
                run();
            } catch (Exception e) {
                Toast.makeText(getActivity(), "getSupportedControlLines() failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                rtsBtn.setVisibility(View.INVISIBLE);
                ctsBtn.setVisibility(View.INVISIBLE);
                dtrBtn.setVisibility(View.INVISIBLE);
                dsrBtn.setVisibility(View.INVISIBLE);
                cdBtn.setVisibility(View.INVISIBLE);
                cdBtn.setVisibility(View.INVISIBLE);
                riBtn.setVisibility(View.INVISIBLE);
            }
        }

        void stop() {
            mainLooper.removeCallbacks(runnable);
            rtsBtn.setChecked(false);
            ctsBtn.setChecked(false);
            dtrBtn.setChecked(false);
            dsrBtn.setChecked(false);
            cdBtn.setChecked(false);
            riBtn.setChecked(false);
        }
    }
}
